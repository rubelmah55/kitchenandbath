<div id="preview-window">
	<a href="#" id="preview-close"></a>
	<div id="preview-title"><h1><?php _e('Preview grid', 'uber-grid')?></h1></div>
	<div id="preview-content"></div>
	<div id="preview-footer">
		<a href="#" id="preview-footer-close" class="button media-button button-primary button-large media-button-select"><?php _e('Close preview', 'uber-grid')?></a>
	</div>
</div>
<div id="preview-backdrop"></div>