<div class="ubergrid-ajax-wrapper">
	<?php echo ubergrid($id, array('buttons' => false, 'lightbox' => false)) ?>
</div>