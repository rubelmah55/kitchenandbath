<?php
define('UBERGRID_CACHE_DIR', 'uber-grid-cache');